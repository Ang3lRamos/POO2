import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class Carrito {
    private JLabel lblNombre;
    private JTextField txtNombre;
    private JLabel lblCantidad;
    private JTextField txtCantidad;
    private JLabel lblPrecio;
    private JTextField txtPrecio;
    private JTextField txtTotal;
    private JButton btnGuardar;
    private JTable tblDatos;
    public JPanel pnlMain;
    private JButton totalButton;
    private JLabel lblTotal;


    private List<Producto> usuarios = new ArrayList<Producto>();

    public Carrito() {
        String[] cols = {"Nombre", "Cantidad", "Precio"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        tblDatos.setModel(model);

        ButtonGroup buttonGroup = new ButtonGroup();

        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[] data = {txtNombre.getText(), txtCantidad.getText(), txtPrecio.getText(), txtTotal};
                model.addRow(data);
                txtNombre.setText("");
                txtCantidad.setText("");
                txtPrecio.setText("");
            }
        });

        totalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                float to = Integer.parseInt(txtPrecio.getText());
                float ca = Integer.parseInt(txtCantidad.getText());
                JOptionPane.showMessageDialog(new JFrame(), "El total a pagar es: " + (to * ca));
            }
        });
    }
}
