import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
public class RegistroIn {
    private JRadioButton carroRadioButton;
    private JRadioButton motoRadioButton;
    private JTextField textMarca;
    private JTextField textModelo;
    private JTextField textPlaca;
    private JTextField textFechaIn;
    private JLabel lblTipoVehiculo;
    private JLabel lblMarca;
    private JLabel lblModelo;
    private JLabel lblPlaca;
    private JLabel lblFechaEntrada;
    private JLabel lblFechaSalida;
    private JTextField textFechaSal;
    private JButton calcularTarifaButton;
    private JLabel lblTarifa;
    private JTextField textTarifa;
    public JPanel registroMain;
    private JLabel lblHoraEntrada;
    private JTextField textHoraIn;
    private JTextField textHoraSal;
    private JLabel lblHoraSalida;
    private String TVehiculo;
    public RegistroIn() {
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(motoRadioButton);
        buttonGroup.add(carroRadioButton);
        motoRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TVehiculo = "Moto";
            }
        });
        carroRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TVehiculo = "Carro";
            }
        });
        calcularTarifaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!textMarca.getText().isEmpty() && !textModelo.getText().isEmpty() && !textPlaca.getText().isEmpty()
                        && !textTarifa.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(new JFrame(), "Tipo de vehiculo: " + TVehiculo.toString() + "\nMarca:"
                            + textMarca.getText() + "\nModelo: " +
                            textModelo.getText() + "\nPlaca: " + textPlaca.getText() + "\nValor hora: " + textTarifa.getText() + " pesos."
                            + "\nFecha de Ingreso: " + textFechaIn.getText() + "\nFecha de Salida: " + textFechaSal.getText()
                             + "\nHora de ingreso: " + textHoraIn.getText() + "\nHora de salida: " + textHoraSal.getText());
                }
            }
        });
        calcularTarifaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    float Tarifa = Float.parseFloat(textTarifa.getText());
                    SimpleDateFormat format = new  SimpleDateFormat("HH:mm:ss");
                    Date horaUn = format.parse(textHoraIn.getText());
                    Date horaDo = format.parse(textHoraSal.getText());
                    long timeDiff = Math.abs(horaDo.getTime()-horaUn.getTime());
                    long horas = TimeUnit.HOURS.convert(timeDiff, TimeUnit.MILLISECONDS);
                    SimpleDateFormat format1 = new  SimpleDateFormat("dd/MM/yyyy");
                    Date fecha1 = format1.parse(textFechaIn.getText());
                    Date fecha2 = format1.parse(textFechaSal.getText());
                    long difeTi = Math.abs(fecha2.getTime()-fecha1.getTime());
                    long dias = TimeUnit.HOURS.convert(difeTi, TimeUnit.MILLISECONDS);
                    JOptionPane.showMessageDialog(new JFrame(),"El precio de la tarifa es: "+ (horas+dias) * Tarifa );
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(new JFrame(), "Error: Digite la fecha y hora de forma correcta.");
                }
            }
        });
    }
}
