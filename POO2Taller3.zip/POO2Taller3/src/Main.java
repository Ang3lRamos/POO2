import javax.swing.*;

public class Main {

    public static void main (String []args){
        JFrame frame = new JFrame("Hilos" );
        frame.setSize(200,200);
        frame.setContentPane(new Semaforos().pnlSemaforos);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
