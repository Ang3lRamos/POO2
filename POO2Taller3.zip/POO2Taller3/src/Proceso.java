
import java.awt.Color;
import static java.lang.Thread.sleep;
import javax.swing.*;
public class Proceso implements Runnable{

    JButton btnRojo;
    JButton btnAmarillo;
    JButton btnVerde;
    int contador = 0;

    public Proceso(JButton entrada1, JButton entrada2, JButton entrada3){

        this.btnRojo = entrada1;
        this.btnAmarillo = entrada2;
        this.btnVerde = entrada3;
    }

    @Override
    public void run(){
        while (true){

            contador++;


            if(contador==1){
                btnRojo.setBackground(Color.gray);
                btnAmarillo.setBackground(Color.gray);
                btnVerde.setBackground(Color.green);
            }

            if(contador==5){
                btnRojo.setBackground(Color.gray);
                btnAmarillo.setBackground(Color.yellow);
                btnVerde.setBackground(Color.gray);
            }

            if(contador==7){
                btnRojo.setBackground(Color.red);
                btnAmarillo.setBackground(Color.gray);
                btnVerde.setBackground(Color.gray);
            }

            if(contador==9){
                btnRojo.setBackground(Color.red);
                btnAmarillo.setBackground(Color.gray);
                btnVerde.setBackground(Color.gray);
            }
            if(contador==11){
                btnRojo.setBackground(Color.gray);
                btnAmarillo.setBackground(Color.gray);
                btnVerde.setBackground(Color.green);
            }
            if(contador==11){
                contador=0;
            }
            try{
                sleep(1000);
            }catch (Exception e){
            }
        }
    }
    public void start(){
        new Thread(this).start();
    }
}
