import javax.swing.*;
import java.awt.*;

import static java.lang.Thread.sleep;

public class Proceso2 implements Runnable{

    JButton btnRojo2;
    JButton btnAmarillo2;
    JButton btnVerde2;
    int contador = 0;

    public Proceso2(JButton entrada4, JButton entrada5, JButton entrada6){

        this.btnRojo2 = entrada4;
        this.btnAmarillo2 = entrada5;
        this.btnVerde2 = entrada6;
    }

    @Override
    public void run(){
        while (true){

            contador++;

            if(contador==1){
                btnRojo2.setBackground(Color.red);
                btnAmarillo2.setBackground(Color.gray);
                btnVerde2.setBackground(Color.gray);
            }

            if(contador==5){
                btnRojo2.setBackground(Color.red);
                btnAmarillo2.setBackground(Color.gray);
                btnVerde2.setBackground(Color.gray);
            }

            if(contador==7){
                btnRojo2.setBackground(Color.gray);
                btnAmarillo2.setBackground(Color.gray);
                btnVerde2.setBackground(Color.green);
            }

            if(contador==9){
                btnRojo2.setBackground(Color.gray);
                btnAmarillo2.setBackground(Color.yellow);
                btnVerde2.setBackground(Color.gray);
            }
            if(contador==11){
                btnRojo2.setBackground(Color.red);
                btnAmarillo2.setBackground(Color.gray);
                btnVerde2.setBackground(Color.gray);
            }
            if(contador==11){
                contador=0;
            }
            try{
                sleep(1000);
            }catch (Exception e){
            }
        }
    }
    public void start(){
        new Thread(this).start();
    }
}


