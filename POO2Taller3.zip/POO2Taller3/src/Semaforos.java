import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Semaforos {
    private JButton iniciarButton;
    private JButton btnRojo;
    private JButton btnAmarillo;
    private JButton btnVerde;
    private JButton btnRojo2;
    private JButton btnAmarillo2;
    private JButton btnVerde2;
    private JLabel txtSemaforo1;
    private JLabel txtSemaforo2;
    public JPanel pnlSemaforos;

    public Semaforos() {
        iniciarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Proceso objeto = new Proceso(btnRojo,btnAmarillo,btnVerde);
                objeto.start();

                Proceso2 objeto2 = new Proceso2(btnRojo2,btnAmarillo2,btnVerde2);
                objeto2.start();
            }
        });
    }
}
